const globalDefaultStyle: Object = {
  padding: '10px',
  margin: '10px',
  borderRadius: '5px',
  border: '1px Solid grey',
  fontFamily: 'Helvetica Neue',
  textAlign: 'left'
};

export default globalDefaultStyle;
