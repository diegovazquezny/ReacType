const prefixer = require('autoprefixer');

module.exports = {
  plugins: [prefixer],
};
